#include <cstdlib>
#include <vector>
#include <iostream>
#include <fstream>
#include "graph.h"

// Save the graph object in a Graphviz dot file format
void save_graph(Graph &g, char *filename);
